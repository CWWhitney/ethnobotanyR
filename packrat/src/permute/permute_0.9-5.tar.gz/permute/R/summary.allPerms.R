`summary.allPerms` <- function(object, ...) {
    class(object) <- "summary.allPerms"
    object
}
