"estimateR.matrix" <-
function(x, ...) apply(x, 1, estimateR, ...)
