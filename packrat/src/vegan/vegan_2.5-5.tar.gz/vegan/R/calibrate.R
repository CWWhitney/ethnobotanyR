`calibrate` <- 
    function(object, ...)
{
    UseMethod("calibrate")
}
