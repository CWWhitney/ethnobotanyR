"estimateR" <-
function(x, ...) UseMethod("estimateR")
